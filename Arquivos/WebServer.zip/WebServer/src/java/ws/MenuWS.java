/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import modelo.MenuItem;


/**
 * REST Web Service
 *
 * @author ellen
 */
@Path("menu")
public class MenuWS {

    @Context
    private UriInfo context;

    public MenuWS() {
    }
    
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_XML)
    @Path("Menu/XML")
    public String listItemsXML(){
                        
        List<MenuItem> lista = new ArrayList<MenuItem>();
        
        MenuItem item = new MenuItem("Macarrão", "Macarrão com molho de tomate temperado com manjericão.", "30", "Sim", "206", "https://www.receiteria.com.br/wp-content/uploads/receitas-de-macarrao-com-molho-de-tomate-0.jpg");
        lista.add(item);
        
        MenuItem item2 = new MenuItem("Frango Empanado", "Frango empanado temperado com sal, alho e pimenta.", "15", "Sim", "297", "https://xtudoreceitas.com/wp-content/uploads/File-de-Frango-Empanado-Integral.jpg");
        lista.add(item2);
        
        MenuItem item3 = new MenuItem("Risoto de Alho Poró", "Risoto de alho poró preparado com vinho branco e queijo parmesão.", "35", "Não", "241,61", "https://lh3.googleusercontent.com/proxy/-YQnZCRWCOUF0f_lkAEXFiyIOIoKIUeREyZRKuNOEt5-dOAQh9lIu6u_SKGUOTloca_mwZYvgACLv7ff5dbldYxAgptZ4wwPH8Ps8mEsQzKfVFRmhh0");
        lista.add(item3);
        
        MenuItem item4 = new MenuItem("Coca-Cola", "Coca-Cola lata 350ml.", "5,50", "Não", "137", "https://araujo.vteximg.com.br/arquivos/ids/4042618-1000-1000/07894900010015.jpg");
        lista.add(item4);
        
        MenuItem item5 = new MenuItem("Suco de Laranja", "Suco de laranja natural 200ml, sem açúcar.", "4", "Não", "86", "https://comeonburger.com.br/wp-content/uploads/2019/12/laranja.jpg");
        lista.add(item5);
        
        MenuItem item6 = new MenuItem("Água Tônica", "Água tônica Antarctica 350ml.", "3", "Não", "34", "https://a-static.mlcdn.com.br/1500x1500/agua-tonica-antarctica-sem-acucar-350ml/lojasemix/1809p/f51eae96dd55e1907d783be1aecaa66d.jpg");
        lista.add(item6);
        
        MenuItem item7 = new MenuItem("Petit Gateau", "Petit Gateau com calda de chocolate. Acompanha sorvete de creme.", "15", "Sim", "575", "https://s2.glbimg.com/nVITzIxbO-YXR2TQ4f3YguOJQrk=/696x390/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_e84042ef78cb4708aeebdf1c68c6cbd6/internal_photos/bs/2020/y/S/hAEF8hShupx3YgwPrDiw/petit-gateau-de-chocolate-com-sorvete.jpg");
        lista.add(item7);
        
        MenuItem item8 = new MenuItem("Sagu com Vinho", "Sagu preparado com vinho tinto e cravos. Acompanha creme inglês.", "7", "Não", "287", "https://vinhosweb.com.br/app/wp-content/uploads/2020/07/sagu-de-vinho-tinto.jpg");
        lista.add(item8);
        
        String response="<?xml version='1.0'?>" 
                +"<Menu>";
        for(MenuItem menuitem : lista){
            response = response +"<MenuItem>"
                +"<name>" + menuitem.getName() + "</name>"
                +"<description>" + menuitem.getDescription() + "</description>"
                +"<price>"+ menuitem.getPrice() +"</price>"
                +"<gluten>"+ menuitem.getGluten() +"</gluten>"
                +"<cal>"+ menuitem.getCal() +"</cal>"
                +"<image>"+ menuitem.getImage() +"</image>"
                +"</MenuItem>";
        }
        response = response + "</Menu>";
               
        return response;
    }
    
    
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public String listItemsJSON(){
        
        List<MenuItem> lista = new ArrayList<MenuItem>();
        
        MenuItem item = new MenuItem("Macarrão", "Macarrão com molho de tomate temperado com manjericão.", "30", "Sim", "206", "https://www.receiteria.com.br/wp-content/uploads/receitas-de-macarrao-com-molho-de-tomate-0.jpg");
        lista.add(item);
        
        MenuItem item2 = new MenuItem("Frango Empanado", "Frango empanado temperado com sal, alho e pimenta.", "15", "Sim", "297", "https://xtudoreceitas.com/wp-content/uploads/File-de-Frango-Empanado-Integral.jpg");
        lista.add(item2);
        
        MenuItem item3 = new MenuItem("Risoto de Alho Poró", "Risoto de alho poró preparado com vinho branco e queijo parmesão.", "35", "Não", "241,61", "https://lh3.googleusercontent.com/proxy/-YQnZCRWCOUF0f_lkAEXFiyIOIoKIUeREyZRKuNOEt5-dOAQh9lIu6u_SKGUOTloca_mwZYvgACLv7ff5dbldYxAgptZ4wwPH8Ps8mEsQzKfVFRmhh0");
        lista.add(item3);
        
        MenuItem item4 = new MenuItem("Coca-Cola", "Coca-Cola lata 350ml.", "5,50", "Não", "137", "https://araujo.vteximg.com.br/arquivos/ids/4042618-1000-1000/07894900010015.jpg");
        lista.add(item4);
        
        MenuItem item5 = new MenuItem("Suco de Laranja", "Suco de laranja natural 200ml, sem açúcar.", "4", "Não", "86", "https://comeonburger.com.br/wp-content/uploads/2019/12/laranja.jpg");
        lista.add(item5);
        
        MenuItem item6 = new MenuItem("Água Tônica", "Água tônica Antarctica 350ml.", "3", "Não", "34", "https://a-static.mlcdn.com.br/1500x1500/agua-tonica-antarctica-sem-acucar-350ml/lojasemix/1809p/f51eae96dd55e1907d783be1aecaa66d.jpg");
        lista.add(item6);
        
        MenuItem item7 = new MenuItem("Petit Gateau", "Petit Gateau com calda de chocolate. Acompanha sorvete de creme.", "15", "Sim", "575", "https://s2.glbimg.com/nVITzIxbO-YXR2TQ4f3YguOJQrk=/696x390/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_e84042ef78cb4708aeebdf1c68c6cbd6/internal_photos/bs/2020/y/S/hAEF8hShupx3YgwPrDiw/petit-gateau-de-chocolate-com-sorvete.jpg");
        lista.add(item7);
        
        MenuItem item8 = new MenuItem("Sagu com Vinho", "Sagu preparado com vinho tinto e cravos. Acompanha creme inglês.", "7", "Não", "287", "https://vinhosweb.com.br/app/wp-content/uploads/2020/07/sagu-de-vinho-tinto.jpg");
        lista.add(item8);
        
        
        Gson g = new Gson();
        
        return g.toJson(lista);
    }
}
