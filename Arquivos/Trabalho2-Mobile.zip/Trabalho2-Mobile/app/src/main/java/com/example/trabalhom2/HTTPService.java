package com.example.trabalhom2;

import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Menu;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class HTTPService extends AsyncTask<Void, Void, ArrayList<MenuItem>> {
    Context context;
    public HTTPService(Context context) { // Constructor
        this.context = context;
    }
    @Override
    protected ArrayList<MenuItem> doInBackground(Void... voids) {
        StringBuilder response = new StringBuilder();
        try {
            URL url = new URL("http://192.168.1.179:8080/WebServer/webresources/menu");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setConnectTimeout(5000);
            connection.connect();
            InputStream in = new BufferedInputStream(connection.getInputStream());
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            ArrayList<MenuItem> menuItems = new ArrayList<>();
            DbHelper dbHelper = new DbHelper(this.context); // Get the db helper

            Cursor cursor = dbHelper.ViewData(); // Get the cursor to view the data

            while(cursor.moveToNext()){ // Iterate through the cursor
                // Create new menu item with the data from the database
                MenuItem menuItem = new MenuItem(cursor.getString(1), cursor.getString(2), cursor.getString(3),  cursor.getString(4), cursor.getString(5), cursor.getString(6));
                menuItems.add(menuItem); // Add menu item to the list of menu items
            }
            return menuItems;
            //e.printStackTrace();
        }
        Type itemListType = new TypeToken<ArrayList<MenuItem>>(){}.getType();
        ArrayList<MenuItem> itemsArray = new Gson().fromJson(response.toString(), itemListType);
        return itemsArray;
    }
}
