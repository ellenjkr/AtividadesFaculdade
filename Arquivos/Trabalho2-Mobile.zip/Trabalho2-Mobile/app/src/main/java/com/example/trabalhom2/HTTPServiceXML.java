package com.example.trabalhom2;

import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class HTTPServiceXML extends AsyncTask<Void, Void, ArrayList<MenuItem>> {
    Context context;
    public HTTPServiceXML(Context context) { // Constructor
        this.context = context;
    }
    @Override
    protected ArrayList<MenuItem> doInBackground(Void... voids) {
        ArrayList<MenuItem> itemsList = new ArrayList<>();
        try {
            URL url = new URL("http://192.168.1.179:8080/WebServer/webresources/menu/Menu/XML");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/xml");
            connection.setConnectTimeout(5000);
            connection.connect();

            InputStream is = null;
            try {
                is = connection.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = null;
            try {
                dBuilder = dbFactory.newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }
            Document doc = null;
            try {
                doc = dBuilder.parse(is);
            } catch (IOException | SAXException e) {
                e.printStackTrace();
            }

            NodeList nList = doc.getElementsByTagName("MenuItem");
            for (int i = 0; i < nList.getLength(); i++) {
                NodeList childrenTags=nList.item(i).getChildNodes();
                int childrenTagsCount=childrenTags.getLength();

                String name = childrenTags.item(0).getTextContent();
                String description = childrenTags.item(1).getTextContent();
                String price = childrenTags.item(2).getTextContent();
                String gluten = childrenTags.item(3).getTextContent();
                String cal = childrenTags.item(4).getTextContent();
                String image = childrenTags.item(5).getTextContent();

                MenuItem newMenuItem= new MenuItem(name, description, price, gluten, cal, image);
                itemsList.add(newMenuItem);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            ArrayList<MenuItem> menuItems = new ArrayList<>();
            DbHelper dbHelper = new DbHelper(this.context); // Get the db helper

            Cursor cursor = dbHelper.ViewData(); // Get the cursor to view the data

            while(cursor.moveToNext()){ // Iterate through the cursor
                // Create new menu item with the data from the database
                MenuItem menuItem = new MenuItem(cursor.getString(1), cursor.getString(2), cursor.getString(3),  cursor.getString(4), cursor.getString(5), cursor.getString(6));

                menuItems.add(menuItem); // Add menu item to the list of menu items
            }
            return menuItems;
            //e.printStackTrace();
        }
        return itemsList;
    }
}
