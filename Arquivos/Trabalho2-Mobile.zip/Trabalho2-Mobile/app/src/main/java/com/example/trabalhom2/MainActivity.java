package com.example.trabalhom2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.VoiceInteractor;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;





public class MainActivity extends AppCompatActivity {
    private ListView menuItemsListView; // ListView for the menu items
    private ArrayList<MenuItem> menuItems = new ArrayList<>(); // Array with menu items
    private Adapter adapter; // Adapter for the menu items
    String method = "JSON";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Defines the layout

        getSupportActionBar().setTitle("Cardápio"); // Set title for the activity

// ================================================================
    // XML
    if(method == (String) "XML") {
        HTTPServiceXML servicexml = new HTTPServiceXML(this);

        try {
            ArrayList<MenuItem> items = servicexml.execute().get();
            DbHelper dbHelper = new DbHelper(MainActivity.this); // Get the db helper
            dbHelper.deleteData();
            for (MenuItem item : items) {
                dbHelper.saveData(item);
                menuItems.add(item);
            }

        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    else {
// ================================================================
        // JSON

        HTTPService service = new HTTPService(this);

        try {
            ArrayList<MenuItem> items = service.execute().get();
            DbHelper dbHelper = new DbHelper(MainActivity.this); // Get the db helper
            dbHelper.deleteData();
            for (MenuItem item : items) {
                dbHelper.saveData(item);
                menuItems.add(item);
            }

        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
// ================================================================

        //addMenuItems(); // Add menu items to the array of menu items
        adapter = new Adapter(this, menuItems); // Creates adapter
        menuItemsListView = (ListView) findViewById(R.id.menuItemsListView); // Get listview
        menuItemsListView.setAdapter(adapter); // Set adapter, responsible for filling the listview with the menu items
    }
}